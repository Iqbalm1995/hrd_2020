	</div>
</body>
<!-- chartjs:js -->
<script src="<?= base_url('assets/') ?>vendors/chart.js/Chart.min.js"></script>
<script src="<?= base_url('assets/') ?>vendors/chart.js/Chart.utils.js"></script>
<script src="<?= base_url('assets/') ?>vendors/chart.js/Chart.example.js"></script>
<!-- endinject -->
</html>