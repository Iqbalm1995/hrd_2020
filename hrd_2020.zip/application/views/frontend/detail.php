	<div class="section-spacing"></div><br><br>
	<div class="ui container centered grid">
		<div class="row">
			<div class="twelve wide computer column">
				<div class="ui grid">
					<div class="sixteen wide computer sixteen wide phone centered column">
						<div class="ui raised segment">
						    <div class="content">
						        <img src="https://www.tuningblog.eu/wp-content/uploads/2020/07/Fast-Furious-Paul-Walker-Toyota-Supra-MK4-Replika-Header.jpg" alt="" class="center-cropped-detail">
						        <h2>Japanese Animation TV Ranking, 20 Februari 2021</h2>
						        <p class="text-tanggal">20 January 2021 by Admin</p>
						        <div class="text-justify"><br>
						        	Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maxime fugiat magnam, accusamus, aliquid minima animi omnis dignissimos ea explicabo obcaecati impedit odit recusandae, nulla deleniti suscipit fugit esse. Enim consectetur animi laboriosam facilis excepturi aut architecto in. Eligendi, enim, consequatur.
						        </div>
						        <ul>
						        	<li>Lorem ipsum dolor sit amet.</li>
						        	<li>Lorem, ipsum dolor sit.</li>
						        	<li>Lorem, ipsum dolor sit amet.</li>
						        	<li>Lorem, ipsum.</li>
						        </ul>
						        <div class="text-justify">
						        	Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam atque, eum earum quasi autem tempore temporibus eaque quaerat aperiam distinctio.
						        </div>
						        <div class="ui divider"></div>
						        <table class="ui very basic table">
						        	<thead>
						        		<tr>
						        			<th class="five wide">Lorem Ipsum</th>
						        			<th class="five wide">Dolor Sit</th>
						        			<th class="text-center" class="two wide">Status</th>
						        			<th class="text-center" class="four wide">Action</th>
						        		</tr>
						        	</thead>
						        	<tbody>
						        		<tr>
						        			<td>Lorem, ipsum, dolor.</td>
						        			<td>Lorem ipsum, dolor sit.</td>
						        			<td class="text-center"><div class="ui green label">Open</div></td>
						        			<td class="text-center"><a href="<?= base_url('home/apply'); ?>" class="ui primary button">Apply</a></td>
						        		</tr>
						        		<tr>
						        			<td>Lorem, ipsum, dolor.</td>
						        			<td>Lorem ipsum, dolor sit.</td>
						        			<td class="text-center"><div class="ui red label">Full</div></td>
						        			<td class="text-center"><a href="#" class="ui button">Apply</a></td>
						        		</tr>
						        		<tr>
						        			<td>Lorem, ipsum, dolor.</td>
						        			<td>Lorem ipsum, dolor sit.</td>
						        			<td class="text-center"><div class="ui black label">Closed</div></td>
						        			<td class="text-center"><a href="#" class="ui button">Apply</a></td>
						        		</tr>
						        	</tbody>
						        </table>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>