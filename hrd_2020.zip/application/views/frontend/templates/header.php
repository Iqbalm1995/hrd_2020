<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="initial-scale=1, minimum-scale=1, width=device-width" name="viewport">
	<meta name="robots" content="all,follow">
	<title>Document</title>
	<link rel="stylesheet" href="<?= base_url('/assets/vendors/fomantic-ui/semantic.min.custom.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('/assets/css/front.css'); ?>">
	<script src="<?= base_url('assets/vendors/jquery/jquery.min.js'); ?>"></script>
	<script src="<?= base_url('assets/vendors/fomantic-ui/semantic.min.custom.js'); ?>"></script>
</head>
<style>

</style>
<body>
	<div class="ui grid">
		<div class="row">
			<div class="column">
				<div class="ui top fixed menu">
					<div class="item">
						<img src="http://localhost/hrd_2020-dev/assets/images/logo.png" alt="Logo">
					</div>
					<div class="left menu">
						<div class="nav item">
							<strong class="navtext">PT JICO AGUNG</strong>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	