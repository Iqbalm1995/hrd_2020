	<div class="footer">
		<div class="ui container centered grid">
			<div class="row">
				<div class="sixteen wide computer column center aligned">
					<b>2020 SIM REKRUTMEN &mdash; PT. JICOAGUNG</b>
				</div>
			</div>
		</div>
	</div>
</body>