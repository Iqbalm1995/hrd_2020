	<div class="heroholder">
		<div class="hero">
			<div class="ui centered grid">
				<div class="row">
					<div class="eight wide computer sixteen wide phone column center aligned">
						<div class="herotext">
							<div class="herotagline">PT JICO AGUNG</div>
							<div>Lowongan Pekerjaan</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="section-spacing"></div>
	<div class="ui container centered grid">
		<div class="row">
			<div class="twelve wide computer column">
				<div class="ui grid">
					<div class="sixteen wide computer sixteen wide phone centered column">
						<div class="ui raised segment">
						    <div class="content">
						        <div class="ui container centered grid">
						        	<div class="row">
						        		<div class="six wide computer column">
											<img src="https://www.tuningblog.eu/wp-content/uploads/2020/07/Fast-Furious-Paul-Walker-Toyota-Supra-MK4-Replika-Header.jpg" alt="" class="center-cropped">
						        		</div>
						        		<div class="ten wide computer column">
						        			<h3>Japanese Animation TV Ranking, 20 Februari 2021	</h3>
						        			<p class="text-tanggal">20 January 2021 by Admin</p>
						        			<div class="text-justify">
						        				Lorem ipsum dolor sit amet consectetur adipisicing, elit. Ipsum non quidem animi veritatis voluptatem corporis quos corrupti a illum exercitationem.
						        			</div>
						        			<br>
						        			<a href="<?= base_url('home/detail'); ?>" class="ui right floated primary button">Read More</a>
						        		</div>
						        	</div>
						        </div>
						    </div>
						</div>
						<div class="ui raised segment">
						    <div class="content">
						        <div class="ui container centered grid">
						        	<div class="row">
						        		<div class="six wide computer column">
											<img src="https://www.nismo.com/wp-content/uploads/2019/04/exterior_02-1440x960.jpg" alt="" class="center-cropped">
						        		</div>
						        		<div class="ten wide computer column">
						        			<h3>Japanese Animation TV Ranking, 20 Februari 2021	</h3>
						        			<p style="line-height: 0%; font-size: 12px; color: gray">20 January 2021 by Admin</p>
						        			<div style="text-align: justify;">
						        				Lorem ipsum dolor sit amet consectetur adipisicing, elit. Ipsum non quidem animi veritatis voluptatem corporis quos corrupti a illum exercitationem.
						        			</div>
						        			<br>
						        			<a href="<?= base_url('home/detail'); ?>" class="ui right floated primary button">Read More</a>
						        		</div>
						        	</div>
						        </div>
						    </div>
						</div>
						<div class="ui raised segment">
						    <div class="content">
						        <div class="ui container centered grid">
						        	<div class="row">
						        		<div class="six wide computer column">
											<img src="https://img.gta5-mods.com/q95/images/mazda-rx7-fd3s/9ce2e8-20190804121137_1.jpg" alt="" class="center-cropped">
						        		</div>
						        		<div class="ten wide computer column">
						        			<h3>Japanese Animation TV Ranking, 20 Februari 2021	</h3>
						        			<p style="line-height: 0%; font-size: 12px; color: gray">20 January 2021 by Admin</p>
						        			<div style="text-align: justify;">
						        				Lorem ipsum dolor sit amet consectetur adipisicing, elit. Ipsum non quidem animi veritatis voluptatem corporis quos corrupti a illum exercitationem.
						        			</div>
						        			<br>
						        			<a href="<?= base_url('home/detail'); ?>" class="ui right floated primary button">Read More</a>
						        		</div>
						        	</div>
						        </div>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>